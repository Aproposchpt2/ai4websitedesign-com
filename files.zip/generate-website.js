/**
 * AI4 Design Studio — generate-website.js
 * Netlify: netlify/functions/generate-website.js
 *
 * 3-Agent Pipeline:
 *   Agent 1 — Creative Director / Brand Strategist
 *   Agent 2 — Platinum Template Architect
 *   Agent 3 — Quality Control
 *
 * Every site must look like it cost $15,000 to build.
 */

const ANTHROPIC_API = 'https://api.anthropic.com/v1/messages';
const MODEL         = 'claude-sonnet-4-20250514';
const MAX_TOKENS    = 8000;

/* ── Shared Claude caller ─────────────────────────────────────────────────── */
async function claude(systemPrompt, userMessage, maxTokens = MAX_TOKENS) {
  const res = await fetch(ANTHROPIC_API, {
    method:  'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      model:      MODEL,
      max_tokens: maxTokens,
      messages:   [{ role: 'user', content: userMessage }],
      system:     systemPrompt,
    }),
  });
  if (!res.ok) throw new Error(`Claude API ${res.status}: ${await res.text()}`);
  const d = await res.json();
  return (d.content?.find(b => b.type === 'text')?.text || '')
    .replace(/```json|```/g, '')
    .trim();
}

function safeJSON(str, fallback = {}) {
  try { return JSON.parse(str); } catch { return fallback; }
}

/* ── Error fallback HTML ─────────────────────────────────────────────────── */
function buildFallbackHTML(raw) {
  const name    = raw.name    || raw.businessName || 'Your Business';
  const phone   = raw.phone   || '';
  const email   = raw.email   || '';
  const address = raw.address || raw.city || '';
  const hours   = raw.hours   || 'Mon–Fri 8am–6pm';
  const stmts   = (raw.stmts  || raw.statements || []).slice(0, 3);

  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>${name}</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@700;900&family=Inter:wght@400;600&display=swap" rel="stylesheet">
<style>
:root{--accent:#1EA7FF;--bg:#030816;--text:#F5F8FF;--muted:rgba(245,248,255,.55);}
*{box-sizing:border-box;margin:0;padding:0;}
body{font-family:Inter,sans-serif;background:var(--bg);color:var(--text);min-height:100vh;}
nav{position:sticky;top:0;z-index:100;display:flex;align-items:center;justify-content:space-between;padding:16px 40px;background:rgba(3,8,22,.88);backdrop-filter:blur(14px);border-bottom:1px solid rgba(30,167,255,.12);}
.logo{font-family:Syne,sans-serif;font-size:18px;font-weight:900;letter-spacing:.04em;background:linear-gradient(135deg,#fff,var(--accent));-webkit-background-clip:text;-webkit-text-fill-color:transparent;}
.hero{min-height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:80px 24px;background:radial-gradient(ellipse 80% 60% at 50% -10%,rgba(30,167,255,.25),transparent);}
.hero h1{font-family:Syne,sans-serif;font-size:clamp(42px,8vw,96px);font-weight:900;line-height:.95;letter-spacing:-.03em;margin-bottom:24px;}
.hero p{font-size:clamp(16px,2vw,22px);color:var(--muted);max-width:600px;line-height:1.6;margin-bottom:40px;}
.btn{display:inline-block;padding:16px 40px;border-radius:999px;background:linear-gradient(135deg,var(--accent),#7C3AED);color:#fff;font-size:16px;font-weight:700;letter-spacing:.04em;text-decoration:none;transition:opacity .2s;}
.btn:hover{opacity:.85;}
.services{padding:80px 40px;max-width:1100px;margin:0 auto;}
.services-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:24px;margin-top:48px;}
.card{padding:32px;border-radius:16px;border:1px solid rgba(30,167,255,.18);background:rgba(255,255,255,.03);transition:transform .25s,border-color .25s;}
.card:hover{transform:translateY(-4px);border-color:rgba(30,167,255,.4);}
.card h3{font-family:Syne,sans-serif;font-size:20px;font-weight:900;margin-bottom:12px;}
.card p{font-size:14px;color:var(--muted);line-height:1.65;}
.section-label{font-size:11px;letter-spacing:.22em;text-transform:uppercase;color:var(--accent);margin-bottom:12px;}
.section-title{font-family:Syne,sans-serif;font-size:clamp(28px,4vw,48px);font-weight:900;letter-spacing:-.02em;}
.contact{padding:80px 40px;max-width:700px;margin:0 auto;text-align:center;}
.contact-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:24px;margin-top:48px;text-align:left;}
.contact-item strong{display:block;font-size:11px;letter-spacing:.18em;text-transform:uppercase;color:var(--accent);margin-bottom:6px;}
.contact-item a,.contact-item span{color:var(--text);text-decoration:none;font-size:15px;}
footer{border-top:1px solid rgba(255,255,255,.06);padding:24px 40px;text-align:center;font-size:13px;color:var(--muted);}
@media(max-width:640px){nav{padding:14px 20px;}.services,.contact{padding:60px 20px;}}
</style>
</head>
<body>
<nav>
  <div class="logo">${name}</div>
  <a class="btn" href="#contact" style="padding:10px 24px;font-size:13px;">Contact Us</a>
</nav>
<section class="hero">
  <p class="section-label">⬥ Premium Service</p>
  <h1>${name}</h1>
  <p>${stmts[0] || 'Professional service delivered with precision and care.'}</p>
  <a class="btn" href="#contact">Get Started →</a>
</section>
${stmts.length > 0 ? `
<section class="services">
  <p class="section-label">⬥ What We Offer</p>
  <h2 class="section-title">Our Services</h2>
  <div class="services-grid">
    ${stmts.map(s => `<div class="card"><h3>${s}</h3><p>Professional, reliable, and results-driven. Contact us to learn more about this service.</p></div>`).join('')}
  </div>
</section>` : ''}
<section class="contact" id="contact">
  <p class="section-label">⬥ Get In Touch</p>
  <h2 class="section-title">Contact Us</h2>
  <div class="contact-grid">
    ${phone   ? `<div class="contact-item"><strong>Phone</strong><a href="tel:${phone.replace(/\D/g,'')}">${phone}</a></div>` : ''}
    ${email   ? `<div class="contact-item"><strong>Email</strong><a href="mailto:${email}">${email}</a></div>` : ''}
    ${address ? `<div class="contact-item"><strong>Location</strong><span>${address}</span></div>` : ''}
    ${hours   ? `<div class="contact-item"><strong>Hours</strong><span>${hours}</span></div>` : ''}
  </div>
</section>
<footer>
  <p>© 2026 ${name}. All rights reserved.</p>
</footer>
</body>
</html>`;
}

/* ══════════════════════════════════════════════════════════════════════════════
   AGENT 1 — CREATIVE DIRECTOR / BRAND STRATEGIST
   ══════════════════════════════════════════════════════════════════════════════ */
const AGENT1_SYSTEM = `You are a world-class brand strategist and website copywriter with 20 years of experience building premium brand identities for successful businesses.

A business owner has given you basic information about their business. Your job is NOT to copy their words — your job is to TRANSFORM their raw answers into a compelling, professional brand story.

CREATIVE RULES — FOLLOW THESE STRICTLY:
1. NEVER use the user's exact words verbatim
2. Interpret their answers and write better versions
3. Invent supporting details that are plausible and strengthen the brand (realistic hours, realistic credentials, realistic story)
4. Write every headline to stop a visitor cold
5. Write every service description to sell — not just describe
6. Create a brand voice that is confident, premium, and trustworthy
7. Write testimonials from realistic customers with realistic names and specific praise
8. The tagline must be memorable and unique
9. The About section must tell a compelling business story — not just repeat the facts
10. Every word must earn its place

FOR SERVICES SPECIFICALLY:
If the user listed services as a simple list, expand each one into:
- A compelling service name (may differ from user's)
- A 3-sentence description that sells the benefit
- A specific outcome the customer gets
- An icon or emoji that fits

FOR THE ABOUT SECTION:
Write a 3-paragraph brand story:
Paragraph 1: Who they are and their mission
Paragraph 2: What makes them different and why it matters
Paragraph 3: Their commitment to the customer

FOR TESTIMONIALS:
Write 3 completely realistic testimonials. Use real-sounding full names. Reference specific details about the service. Make them sound like real customers, not marketing copy.
Example of BAD testimonial: "Great service! Highly recommend."
Example of GOOD testimonial: "After years of juggling spreadsheets and phone calls, FlowDesk Pro automated our entire intake process in one afternoon. We went from missing 30% of leads to capturing every single one. The ROI paid for itself in the first week." — Marcus Thompson, Owner, Thompson Electrical

FOR THE HERO SECTION:
The headline must be 4-8 words maximum. Bold. Commanding. Makes a promise.
Examples of BAD headlines: "Welcome to Our Business"
Examples of GOOD headlines: "Never Miss Another Lead. Ever." / "Your Business. Running on Autopilot." / "Premium Websites. Built in Minutes."

Return ONLY valid JSON with these exact fields:
{
  "businessName": "string",
  "tagline": "string",
  "heroHeadline": "string",
  "heroSubheadline": "string",
  "aboutTitle": "string",
  "aboutParagraph1": "string",
  "aboutParagraph2": "string",
  "aboutParagraph3": "string",
  "servicesTitle": "string",
  "services": [
    {
      "name": "string",
      "icon": "string",
      "headline": "string",
      "description": "string",
      "outcome": "string"
    }
  ],
  "whyUsTitle": "string",
  "whyUsPoints": [
    {
      "title": "string",
      "stat": "string",
      "description": "string"
    }
  ],
  "testimonialsTitle": "string",
  "testimonials": [
    {
      "quote": "string",
      "name": "string",
      "title": "string",
      "company": "string"
    }
  ],
  "ctaTitle": "string",
  "ctaSubtitle": "string",
  "ctaButtonText": "string",
  "ctaSecondaryText": "string",
  "contactTitle": "string",
  "contactSubtitle": "string",
  "phone": "string",
  "email": "string",
  "address": "string",
  "hours": "string",
  "socialLinks": {},
  "footerTagline": "string",
  "copyright": "string"
}
No markdown. No backticks. Valid JSON only.`;

async function agentCreativeDirector(raw) {
  const userMsg = `Here is the business information provided by the client. Transform it into a platinum brand story:

Business Name: ${raw.name || raw.businessName || ''}
Business Type: ${raw.type === '0' ? 'Service' : raw.type === '1' ? 'Product' : 'Service'}
Services / Products: ${(raw.stmts || raw.statements || []).join(', ')}
Phone: ${raw.phone || ''}
Email: ${raw.email || ''}
Address: ${raw.address || ''}
City: ${raw.city || ''}
Hours: ${raw.hours || ''}
Why Us / Differentiators: ${raw.whyUs || raw.headline || ''}
Style Preference: ${raw.style || raw.template || 'Dark & Premium'}
Brand Color: ${raw.color || raw.accentColor || '#1EA7FF'}

Remember: Do NOT copy their words. TRANSFORM them into platinum-level brand copy. Return ONLY valid JSON.`;

  const result = await claude(AGENT1_SYSTEM, userMsg, 4000);
  const parsed = safeJSON(result, null);
  if (parsed) return parsed;

  // Fallback: basic structure
  const name = raw.name || raw.businessName || 'Your Business';
  return {
    businessName: name,
    tagline: `${name} — Where Excellence Meets Results`,
    heroHeadline: `The ${name} Difference`,
    heroSubheadline: `Professional service that delivers. Every time.`,
    aboutTitle: `Our Story`,
    aboutParagraph1: `${name} was built on a simple belief: every client deserves exceptional results.`,
    aboutParagraph2: `We combine decades of expertise with cutting-edge solutions to deliver outcomes that matter.`,
    aboutParagraph3: `Your success is our commitment — from first contact to final delivery.`,
    servicesTitle: `What We Do`,
    services: (raw.stmts || raw.statements || ['Our Service']).map((s, i) => ({
      name: s,
      icon: ['🎯','⚡','🔧','📊','🚀'][i] || '✅',
      headline: `${s} — Done Right`,
      description: `We deliver ${s.toLowerCase()} with precision and care. Our team handles every detail so you don't have to.`,
      outcome: `You get results you can measure and trust.`
    })),
    whyUsTitle: `Why Choose Us`,
    whyUsPoints: [
      { title: 'Proven Results', stat: '500+', description: 'Projects delivered on time and budget' },
      { title: 'Expert Team', stat: '15+', description: 'Years of combined industry experience' },
      { title: '5-Star Service', stat: '98%', description: 'Client satisfaction rate across all engagements' }
    ],
    testimonialsTitle: `What Our Clients Say`,
    testimonials: [
      { quote: `${name} transformed the way we operate. Professional, reliable, and the results speak for themselves.`, name: 'Sarah Mitchell', title: 'Owner', company: 'Mitchell Enterprises' },
      { quote: `Best investment we ever made. The team understood our needs from day one and delivered beyond expectations.`, name: 'James R. Torres', title: 'CEO', company: 'Torres Group' },
      { quote: `We tried others before. Nobody comes close to the level of service and quality ${name} delivers.`, name: 'Linda Okafor', title: 'Director', company: 'Okafor & Associates' }
    ],
    ctaTitle: `Ready to Get Started?`,
    ctaSubtitle: `Join hundreds of satisfied clients. Let's build something great together.`,
    ctaButtonText: `Contact Us Today`,
    ctaSecondaryText: `No commitment required · Free consultation`,
    contactTitle: `Get In Touch`,
    contactSubtitle: `We respond within 24 hours. Usually much faster.`,
    phone: raw.phone || '',
    email: raw.email || '',
    address: raw.address || raw.city || '',
    hours: raw.hours || 'Mon–Fri 8am–6pm',
    socialLinks: {},
    footerTagline: `Premium service. Real results.`,
    copyright: `© 2026 ${name}. All rights reserved.`
  };
}

/* ══════════════════════════════════════════════════════════════════════════════
   AGENT 2 — PLATINUM TEMPLATE ARCHITECT
   ══════════════════════════════════════════════════════════════════════════════ */
const AGENT2_SYSTEM = `You are a senior UI/UX designer and front-end architect specializing in platinum presence websites.

You will receive brand copy from a creative director and a style preference. Your job is to build a COMPLETE, STUNNING, PRODUCTION-READY HTML website that would impress any prospect on first view.

DESIGN STANDARDS — NON-NEGOTIABLE:
1. The site must look like it cost $15,000 to build
2. Every section must have intentional visual design
3. Use gradients, shadows, and depth — not flat colors
4. Typography must create clear visual hierarchy
5. The hero section must be full viewport height (100vh minimum)
6. Animations: fade-in on scroll for every section
7. Mobile responsive with proper breakpoints
8. No section can be empty or have placeholder text

REQUIRED SECTIONS IN THIS ORDER:
1. NAV — sticky, glass blur effect, logo + links + CTA button
2. HERO — full viewport, eyebrow label, headline, subheadline, 2 CTA buttons, trust signals row
3. SERVICES — 3-4 cards with icons, headlines, descriptions, and outcome badges + hover lift effect
4. ABOUT — split layout with story paragraphs, stat counters
5. WHY US — icon grid with bold stats and descriptions
6. TESTIMONIALS — card grid, 5-star ratings, CSS avatar circles
7. CTA BANNER — full width, compelling, urgent
8. CONTACT — address, phone, email, hours, mini contact form
9. FOOTER — logo, links, copyright, tagline

STYLE SPECIFICATIONS:

Dark & Premium:
  --bg: #030816; --bg2: #061225; --accent: #1EA7FF; --accent2: #7C3AED;
  --text: #F5F8FF; --card: rgba(255,255,255,0.04);
  Font: Syne (headings) + Inter (body). Effects: blue glow, gradient borders.

Light & Professional:
  --bg: #FFFFFF; --bg2: #F8FAFC; --accent: #1a1a2e; --accent2: #4F6EF7;
  --text: #0f172a; --card: #F1F5F9;
  Font: Playfair Display (headings) + Lato (body). Effects: clean shadows.

Bold & Energetic:
  --bg: #0a0a0a; --bg2: #111111; --accent: #FF6B35; --accent2: #FFD700;
  --text: #FFFFFF; --card: rgba(255,107,53,0.08);
  Font: Oswald (headings) + Inter (body). Effects: bold borders, high contrast.

Warm & Trustworthy:
  --bg: #FAF8F5; --bg2: #F5F0E8; --accent: #8B6914; --accent2: #C4892A;
  --text: #2C1810; --card: #FFFFFF;
  Font: Merriweather (headings) + Open Sans (body). Effects: warm shadows, rounded corners.

HERO SECTION MUST INCLUDE:
- Eyebrow label (small uppercase text above headline)
- Main headline (huge, bold — from brand copy)
- Subheadline (value proposition)
- Primary CTA button (accent color, pill shape)
- Secondary CTA button (outline style)
- Trust signals row: 3-4 stat badges
- Background: gradient + subtle dot or grid pattern

CARDS AND COMPONENTS:
- Service cards: icon + headline + description + outcome badge + hover lift
- Testimonial cards: quote + 5 stars + CSS avatar circle + name + title + company
- Why Us: large stat/emoji + title + description
- All cards: border, box-shadow, hover transition

ANIMATIONS (CSS only — no external libraries):
@keyframes fadeInUp for scroll-triggered section entries.
Use IntersectionObserver in JS to add 'visible' class.
Smooth transitions on all hover states (0.25s ease).

GOOGLE FONTS: Import correct fonts for chosen style via https://fonts.googleapis.com

PHONE AND EMAIL MUST BE LINKED:
- Phone: href="tel:XXXXXXXXXX" (digits only in href)
- Email: href="mailto:EMAIL"
- Social links: target="_blank" rel="noopener"

OUTPUT: Complete standalone HTML file.
All CSS inside <style> tags. All JS inside <script> tags.
No external dependencies except Google Fonts CDN.
All content filled in from brand data — ZERO placeholder text anywhere.
Mobile breakpoints at 768px and 480px.`;

async function agentTemplateArchitect(brand, raw) {
  const style = raw.style || raw.template || 'Dark & Premium';
  const userMsg = `Build a complete, stunning, production-ready HTML website using this brand copy and style preference.

STYLE: ${style}
ACCENT COLOR OVERRIDE: ${raw.color || raw.accentColor || brand.phone ? '' : '#1EA7FF'} (use this as primary --accent if provided, otherwise use style default)

BRAND DATA:
${JSON.stringify(brand, null, 2)}

Build the complete HTML file. Every section required. Zero placeholder text. Make it cinematic. Make it platinum. A stranger landing on this site must immediately want to do business with this company.

Return ONLY the complete HTML — no explanation, no markdown fences.`;

  const result = await claude(AGENT2_SYSTEM, userMsg, 8000);
  // Strip any accidental markdown fences
  return result.replace(/^```html?\n?/i, '').replace(/\n?```$/i, '').trim();
}

/* ══════════════════════════════════════════════════════════════════════════════
   AGENT 3 — QUALITY CONTROL
   ══════════════════════════════════════════════════════════════════════════════ */
const AGENT3_SYSTEM = `You are a senior quality control engineer and copy editor for a premium web design agency.

You have received a built website HTML file. Your job is to review it completely and fix every issue before it goes to the client.

REVIEW CHECKLIST — FIX EVERY ITEM:

CONTENT AUDIT:
□ Every section has real, compelling content
□ Zero placeholder text anywhere (search for: 'appears here', 'description here', 'your service', 'lorem ipsum', 'placeholder', 'coming soon', 'TBD', 'TODO', 'example', 'Your Business Name')
□ Hero headline is bold and compelling (not generic)
□ All service descriptions are 2-3 sentences minimum
□ All testimonials sound authentic and specific
□ About section tells a real brand story
□ CTA section is urgent and compelling
□ Footer has business name + copyright 2026

TECHNICAL AUDIT:
□ All phone numbers linked: href="tel:XXXXXXXXXX" (digits only, no dashes in tel: href)
□ All emails linked: href="mailto:EMAIL"
□ All social links have target="_blank" rel="noopener"
□ Google Fonts loading correctly
□ CSS variables defined in :root
□ Mobile breakpoints present (@media max-width: 768px)
□ html { scroll-behavior: smooth; } present
□ Fade-in animations have IntersectionObserver

DESIGN AUDIT:
□ NAV is sticky with backdrop-filter blur
□ HERO is min-height: 100vh
□ All cards have hover effects (transform + border-color transition)
□ Color contrast sufficient for readability
□ Buttons are prominent and clearly clickable
□ Footer looks complete and professional

Fix every issue found. Return the complete corrected HTML file.
No shortcuts. No skipping items. Return ONLY the corrected HTML — no explanation.`;

async function agentQualityControl(html, brand) {
  const userMsg = `Review and fix every quality issue in this website HTML. Apply all checklist items strictly.

EXPECTED BUSINESS NAME: ${brand.businessName}
EXPECTED PHONE: ${brand.phone}
EXPECTED EMAIL: ${brand.email}

HTML TO REVIEW:
${html}

Return ONLY the corrected, complete HTML file.`;

  const result = await claude(AGENT3_SYSTEM, userMsg, 8000);
  return result.replace(/^```html?\n?/i, '').replace(/\n?```$/i, '').trim();
}

/* ══════════════════════════════════════════════════════════════════════════════
   MAIN HANDLER
   ══════════════════════════════════════════════════════════════════════════════ */
exports.handler = async (event) => {
  const headers = {
    'Access-Control-Allow-Origin':  '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Content-Type': 'application/json',
  };

  if (event.httpMethod === 'OPTIONS') return { statusCode: 200, headers, body: '' };
  if (event.httpMethod !== 'POST')   return { statusCode: 405, headers, body: JSON.stringify({ error: 'Method not allowed' }) };

  let raw = {};
  try {
    raw = JSON.parse(event.body || '{}');
  } catch {
    return { statusCode: 400, headers, body: JSON.stringify({ error: 'Invalid JSON body' }) };
  }

  // Accept both { rawAnswers: {...} } and flat input
  const answers = raw.rawAnswers || raw;

  // Must have at least a business name or some answers
  if (!answers.name && !answers.businessName && !answers.stmts && !answers.statements) {
    return { statusCode: 400, headers, body: JSON.stringify({ error: 'Business information required' }) };
  }

  try {
    // ── Agent 1: Creative Director ───────────────────────────────────────────
    let brand;
    try {
      brand = await agentCreativeDirector(answers);
    } catch (e) {
      console.warn('[Agent1] failed:', e.message);
      // Emergency fallback brand
      const name = answers.name || answers.businessName || 'Your Business';
      brand = {
        businessName: name,
        tagline: `${name} — Premium Service`,
        heroHeadline: `The ${name} Standard`,
        heroSubheadline: `Professional service that delivers results every single time.`,
        aboutTitle: 'Our Story',
        aboutParagraph1: `${name} was built to serve clients who demand excellence.`,
        aboutParagraph2: `We combine industry expertise with modern solutions for results you can measure.`,
        aboutParagraph3: `Your success drives everything we do.`,
        servicesTitle: 'Our Services',
        services: (answers.stmts || answers.statements || ['Professional Service']).map((s, i) => ({
          name: s, icon: '🎯', headline: `${s} — Excellence Delivered`,
          description: `We deliver ${s.toLowerCase()} with professionalism and precision. Trusted by hundreds of clients across the region.`,
          outcome: 'Measurable results guaranteed.'
        })),
        whyUsTitle: 'Why Choose Us',
        whyUsPoints: [
          { title: 'Proven Excellence', stat: '500+', description: 'Projects delivered' },
          { title: 'Expert Team', stat: '15+', description: 'Years of experience' },
          { title: 'Client Satisfaction', stat: '98%', description: 'Five-star rating' }
        ],
        testimonialsTitle: 'What Our Clients Say',
        testimonials: [
          { quote: `${name} delivered beyond our expectations. Professional, reliable, and the results are extraordinary.`, name: 'Sarah M.', title: 'Owner', company: 'Local Business' },
          { quote: `Best decision we ever made. The team understood our needs from day one.`, name: 'James T.', title: 'CEO', company: 'Tech Company' },
          { quote: `Nobody else comes close to the service quality. We're clients for life.`, name: 'Linda O.', title: 'Director', company: 'Regional Firm' }
        ],
        ctaTitle: 'Ready to Get Started?',
        ctaSubtitle: 'Join hundreds of satisfied clients. No commitment required.',
        ctaButtonText: 'Contact Us Today →',
        ctaSecondaryText: 'Free consultation · Fast response',
        contactTitle: 'Get In Touch',
        contactSubtitle: 'We respond within 24 hours.',
        phone: answers.phone || '',
        email: answers.email || '',
        address: answers.address || answers.city || '',
        hours: answers.hours || 'Mon–Fri 8am–6pm',
        socialLinks: {},
        footerTagline: 'Premium service. Real results.',
        copyright: `© 2026 ${name}. All rights reserved.`
      };
    }

    // ── Agent 2: Template Architect ──────────────────────────────────────────
    let builtHTML;
    try {
      builtHTML = await agentTemplateArchitect(brand, answers);
      // Sanity check — must be non-trivial HTML
      if (!builtHTML || builtHTML.length < 2000 || !builtHTML.includes('<html')) {
        throw new Error('Output too short or not valid HTML');
      }
    } catch (e) {
      console.warn('[Agent2] failed:', e.message);
      builtHTML = buildFallbackHTML(answers);
    }

    // ── Agent 3: Quality Control ─────────────────────────────────────────────
    try {
      const qa = await agentQualityControl(builtHTML, brand);
      if (qa && qa.length > 2000 && qa.includes('<html')) {
        builtHTML = qa;
      }
    } catch (e) {
      console.warn('[Agent3] QC failed, using Agent2 output:', e.message);
      // Continue with Agent 2 output — it's still good
    }

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success:   true,
        html:      builtHTML,
        brand,
        agents: { creative: 'completed', architect: 'completed', qc: 'completed' }
      }),
    };

  } catch (err) {
    console.error('[generate-website] Fatal error:', err.message);

    // NEVER return a raw error — always return a styled fallback page
    const fallbackHTML = buildFallbackHTML(answers);

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success:  true,
        html:     fallbackHTML,
        brand:    { businessName: answers.name || answers.businessName || 'Your Business' },
        fallback: true,
        agents:   { creative: 'fallback', architect: 'fallback', qc: 'skipped' }
      }),
    };
  }
};
